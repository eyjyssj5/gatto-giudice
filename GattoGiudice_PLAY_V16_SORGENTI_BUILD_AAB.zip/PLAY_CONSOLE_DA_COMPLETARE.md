# Il Gatto Giudice | Pacchetto commerciale Google Play

**BASE:** V15 definitiva. Le sei foto, le 12 lingue, il microfono, il cambio dei gatti esclusivamente manuale e l'icona originale non sono stati sostituiti.

**PACCHETTO SORGENTE: NON è un .aab compilato.**

## Per compilare un AAB firmato

1. Nel repository GitHub `eyjyssj5/gatto-giudice`, selezionare il ramo `play-commercial-v16` e caricare COME SINGOLO FILE lo ZIP `GattoGiudice_PLAY_V16_SORGENTI_BUILD_AAB.zip` tramite Add file > Upload files. Non estrarlo.
   Il workflow pronto nel ramo legge e decomprime quello ZIP durante la compilazione.
2. Prima della compilazione, su GitHub, `Settings > Secrets and variables > Actions`, registrare i quattro segreti presenti nell’archivio PRIVATO `GattoGiudice_V16_CHIAVE_UPLOAD_PRIVATA.zip` (solo per app NUOVA, se non esiste già una chiave upload registrata):
   - `GATTO_UPLOAD_KEYSTORE_B64`: contenuto Base64 della chiave upload `.jks` (comando `base64 -w0 nome.jks` su Linux).
   - `GATTO_UPLOAD_STORE_PASSWORD`: password del keystore.
   - `GATTO_UPLOAD_KEY_PASSWORD`: password della chiave.
   - `GATTO_UPLOAD_ALIAS`: alias della chiave.
3. Aprire `Actions > Gatto Giudice V16 - Build AAB da ZIP > Run workflow` e selezionare `play-commercial-v16`.
4. Scaricare l'artefatto `GattoGiudice_Play_AAB_Firmato` e caricarlo nella **traccia di test interno** di Play Console.

Lo script imposta `targetSdkVersion=36`, `compileSdkVersion=36`, AGP 8.11.1, Gradle 8.13. Versione `1.0.0`, versionCode `1`, package `com.aivevia.gattogiudice`.

## Acquisti Google Play (DA ATTIVARE E COLLAUDARE)

La build commerciale prevede Dolce gratis e cinque prodotti **non consumabili**, singoli:

- `giudice_severo_premium`
- `giudice_ironico_premium`
- `giudice_corrotto_premium`
- `giudice_pigro_premium`
- `giudice_supremo_premium`

Occorre creare/attivare questi prodotti in Play Console, stabilire i relativi prezzi, confermare se il modello commerciale desiderato è davvero quello dei cinque acquisti individuali e attivare la **verifica degli scontrini lato server**. La libreria inclusa è `capacitor-plugin-cdv-purchase`. Il codice consente una prova tecnica del flusso ma **non è pronto per la produzione** senza questi passi, test su dispositivo e verifica degli acquisti/ripristini.

## Altri requisiti per la pubblicazione

- URL raggiungibile di informativa privacy, dichiarazioni sicurezza dei dati e microfono, sezione contenuti e classificazione.
- Test del riconoscimento vocale Android nelle lingue scelte.
- Worker Cloudflare aggiornato e verificato: verifica le 6 personalità; l'attuale backend potrebbe essere ancora quello antecedente.
- Antifrode/costi API: il limite `10 sentenze/giorno` in questa preparazione è solo locale; per uso pubblico serve enforcement server.
- La verifica automatica non sostituisce il caricamento e l'ispezione in Play Console.
- Conservare keystore e password: senza chiave upload si rischia di non poter aggiornare l'app senza procedura di reset della chiave.

**IMPORTANTE:** La prima pubblicazione deve usare un certificato upload coerente con quello registrato per questa app in Google Play. Non utilizzare la chiave di un'altra app senza verificarlo.
