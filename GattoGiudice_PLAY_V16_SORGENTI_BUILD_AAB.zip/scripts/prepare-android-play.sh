#!/usr/bin/env bash
set -euo pipefail
# Execute after `npx cap add android && npx cap sync android`.
[ -f android/variables.gradle ] || { echo 'Manca android/variables.gradle'; exit 1; }
python3 - <<'PY'
from pathlib import Path
import re
p=Path('android/variables.gradle');s=p.read_text()
for var,val in [('compileSdkVersion','36'),('targetSdkVersion','36')]:
 updated,n=re.subn(r'(?m)(\b'+var+r'\s*=\s*)\d+',r'\g<1>'+val,s)
 assert n>0,f'Variabile assente: {var}';s=updated
p.write_text(s)
p=Path('android/build.gradle');s=p.read_text();s,n=re.subn(r'com\.android\.tools\.build:gradle:[0-9.]+','com.android.tools.build:gradle:8.11.1',s)
assert n>0,'AGP mancante';p.write_text(s)
p=Path('android/gradle/wrapper/gradle-wrapper.properties');s=p.read_text();s,n=re.subn(r'gradle-[0-9.]+-(all|bin)\.zip','gradle-8.13-bin.zip',s)
assert n>0,'Gradle wrapper mancante';p.write_text(s)
p=Path('android/app/build.gradle');s=p.read_text();s,n=re.subn(r'\bversionCode\s+\d+','versionCode 1',s);assert n>0,'versionCode mancante';s,n=re.subn(r'\bversionName\s+"[^"]+"','versionName "1.0.0"',s);assert n>0,'versionName mancante';p.write_text(s)
p=Path('android/app/src/main/AndroidManifest.xml');s=p.read_text()
if 'android.permission.RECORD_AUDIO' not in s:
 s=s.replace('<application','<uses-permission android:name="android.permission.RECORD_AUDIO" />\n    <application',1)
p.write_text(s)
PY
for f in risorse-icone-android/*; do [ -d "$f" ] || continue; target="android/app/src/main/res/$(basename "$f")"; mkdir -p "$target"; cp -f "$f"/*.png "$target"/; done
printf 'Android per Google Play configurato: targetSdk=36, AGP=8.11.1, Gradle=8.13\n'
