const assert=require('node:assert/strict');
const fs=require('node:fs'), path=require('node:path'),test=require('node:test');
const app=fs.readFileSync(path.join(__dirname,'../www/app.js'),'utf8');
const html=fs.readFileSync(path.join(__dirname,'../www/index.html'),'utf8');
const imageNames=[...app.matchAll(/\{id:"(dolce|severo|ironico|corrotto|pigro|supremo)",img:"img\/([^"]+)"/g)];
test('sei schede, sei ruoli unici, Ironico una sola volta',()=>{
 assert.equal(imageNames.length,6);
 assert.deepEqual(imageNames.map(x=>x[1]),['dolce','severo','ironico','corrotto','pigro','supremo']);
 assert.equal(imageNames.filter(x=>x[1]==='ironico').length,1);
 for(const x of imageNames)assert.ok(fs.existsSync(path.join(__dirname,'../www/img',x[2])));
 assert.equal(imageNames.find(x=>x[1]==='ironico')[2],'gatto-ironico.png');
 assert.equal(imageNames.find(x=>x[1]==='supremo')[2],'gatto-supremo.png');
});
test('il carosello NON scorre automaticamente, neanche quando non si scrive',()=>{
 assert.doesNotMatch(app,/setInterval\s*\(|setTimeout\s*\([^)]*selectIndex|autoplay|lastTouched/);
 assert.match(app,/el\("giudice-prev"\)\.addEventListener\("click"/);
 assert.match(app,/el\("giudice-next"\)\.addEventListener\("click"/);
 assert.match(app,/el\("judges-viewport"\)\.addEventListener\("touchend"/);
 assert.match(app,/b\.addEventListener\("click"/);
});
test('nessuna seconda immagine Ironico nel progetto e cache nuovo codice',()=>{
 assert.ok(!fs.existsSync(path.join(__dirname,'../www/img/gatto-ironico-esatto.webp')));
 assert.match(html,/app\.js\?v=play16/);
});
