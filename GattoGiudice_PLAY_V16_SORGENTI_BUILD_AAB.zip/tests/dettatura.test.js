const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const source=fs.readFileSync('www/app.js','utf8');
const begin=source.indexOf('let recognizer=null;');
const end=source.indexOf('el("btn-detta").addEventListener("click",dictate);')+'el("btn-detta").addEventListener("click",dictate);'.length;
const code=source.slice(begin,end);
const words=['Detta','Ti ascolto','Testo inserito','Tastiera','Errore','Stop'];
test('toccare il microfono Android richiede permesso e scrive testo modificabile, senza inviare', async()=>{
 let starts=0, permissionChecks=0, submit=0, listeningMessage='', callback;
 const elements={
  'btn-detta':{setAttribute(){},addEventListener(evt,cb){if(evt==='click')callback=cb},title:'',textContent:''},
  'dettatura-stato':{set textContent(v){listeningMessage=v}},
  'decisione':{value:'',dispatchEvent(){},focus(){}},
 };
 const native={available:async()=>({available:true}),checkPermissions:async()=>{permissionChecks++;return {speechRecognition:'granted'}},start:async o=>{starts++;assert.equal(o.language,'it-IT');return {matches:['Ho aiutato un amico']}}};
 const context={window:{Capacitor:{Plugins:{SpeechRecognition:native}}},el:id=>elements[id],state:{lingua:'it'},SPEECH_LOCALES:{it:'it-IT'},DICTATION:{it:words},Event:class{},console,submit:()=>submit++};
 vm.runInNewContext(code,context);
 await callback();
 assert.equal(permissionChecks,1);assert.equal(starts,1);assert.equal(elements.decisione.value,'Ho aiutato un amico');assert.equal(submit,0);assert.equal(elements['btn-detta'].textContent,'🎙️');assert.equal(listeningMessage,words[2]);
});
test('senza microfono nativo o browser il pulsante mostra istruzioni invece di non fare nulla',async()=>{
 let message='',clicked;
 const elements={'btn-detta':{setAttribute(){},addEventListener(evt,cb){clicked=cb},title:'',textContent:''},'dettatura-stato':{set textContent(v){message=v}},'decisione':{value:'',focus(){}}};
 vm.runInNewContext(code,{window:{},el:id=>elements[id],state:{lingua:'it'},SPEECH_LOCALES:{it:'it-IT'},DICTATION:{it:words},console});
 await clicked();assert.equal(message,words[3]);
});

test("versione Play mostra solo lucchetti sui giudici Premium, senza targhette",()=>{assert.doesNotMatch(source,/TEST\.ui\(state\.lingua\)\.unlocked/);assert.doesNotMatch(source,/class="tier"/);assert.match(source,/paid\(id\)/);});
