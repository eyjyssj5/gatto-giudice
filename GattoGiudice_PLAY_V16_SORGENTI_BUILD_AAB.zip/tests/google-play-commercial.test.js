const assert=require('node:assert/strict'),fs=require('node:fs'),test=require('node:test');
const app=fs.readFileSync('www/app.js','utf8');const billing=fs.readFileSync('www/premium-entry.js','utf8');const html=fs.readFileSync('www/index.html','utf8');
test('cinque giudici premium e Dolce gratuito',()=>{for(const id of ['severo','ironico','corrotto','pigro','supremo'])assert.match(billing,new RegExp('"'+id+'"'));assert.match(app,/id===(?:'|")dolce(?:'|")/);assert.match(app,/is-locked/);});
test('niente auto-rotazione e niente accesso premium senza acquisto',()=>{assert.doesNotMatch(app,/setInterval\s*\(/);assert.match(app,/!paid\(state\.carattere\)/);});
test('modulo Billing incluso, nessun prezzo inventato',()=>{assert.match(html,/premium-bundle\.js/);assert.match(billing,/NON_CONSUMABLE/);assert.match(billing,/pricing\?\.price/);});
test('12 lingue e microfono ancora disponibili',()=>{assert.match(html,/option value="ar"/);assert.match(html,/option value="zh"/);assert.match(html,/btn-detta/);});

test('acquisti utilizzano product.canPurchase e prezzo reale',()=>{assert.match(billing,/\?\.canPurchase/);assert.match(billing,/\?\.pricing\?\.price/);assert.doesNotMatch(billing,/offer\.canPurchase/);});
test('cambio giudice aggiorna subito lo stato del pulsante',()=>{assert.match(app,/renderJudges\(\);showRemaining\(\)/);});
