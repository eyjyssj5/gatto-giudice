const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');const path=require('node:path');const crypto=require('node:crypto');
const root=path.join(__dirname,'../www');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const pngs={
  dolce:['gatto-dolce-approvato.png','8e3c6a8e234c9cdbee8374ff8909c81b10376c1c325a97548cef3756f3302c45'],
  severo:['gatto-severo-approvato.png','afb92fe3afed6567cb6111be6ae4ab5e71d235fadd173079bd747b9349f9efd1'],
  corrotto:['gatto-corrotto-approvato.png','f186830374d02d16d0f8303d0e643d6a0296297a85fca191dafaa7e1870ec82f'],
  pigro:['gatto-pigro-approvato.png','4965a7b22c929d4226feb2ff136e966978068fcca4ea05c251d02d485650f2f6']
};
test('foto V13 confermate per Dolce, Severo e Pigro; Corrotto corretto V15',()=>{
  for(const [id,[file,hash]] of Object.entries(pngs)){
    assert.match(app,new RegExp('id:"'+id+'",img:"img/'+file.replace('.','\\.')+'"'));
    const v=crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'img',file))).digest('hex');assert.equal(v,hash);
  }
  assert.match(app,/id:"ironico",img:"img\/gatto-ironico\.png"/);
  assert.match(app,/id:"supremo",img:"img\/gatto-supremo\.png"/);
});
