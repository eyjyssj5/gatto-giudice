const assert=require('node:assert/strict'); const fs=require('node:fs');const path=require('node:path');const crypto=require('node:crypto');const {test}=require('node:test');
const root=path.resolve(__dirname,'../www');const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const sha=name=>crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'img',name))).digest('hex');
test('V15: Ironico SENZA targa e Corrotto CON monete sono le due immagini gia approvate',()=>{
 assert.equal(sha('gatto-ironico.png'),'9ddf377085c1fc53e3e28a0cf52f10c16db54b761e744d062a6191f6a0ca7c6b');
 assert.equal(sha('gatto-corrotto-approvato.png'),'f186830374d02d16d0f8303d0e643d6a0296297a85fca191dafaa7e1870ec82f');
});
test('V15: solo scelta manuale, nuove immagini non in cache e altri quattro ritratti intatti',()=>{
 assert.doesNotMatch(app,/setInterval\s*\(|autoplay|lastTouched/);
 assert.match(app,/\?v=16/);
 for(const [name,expected] of Object.entries({"gatto-dolce-approvato.png": "8e3c6a8e234c9cdbee8374ff8909c81b10376c1c325a97548cef3756f3302c45", "gatto-severo-approvato.png": "afb92fe3afed6567cb6111be6ae4ab5e71d235fadd173079bd747b9349f9efd1", "gatto-pigro-approvato.png": "4965a7b22c929d4226feb2ff136e966978068fcca4ea05c251d02d485650f2f6", "gatto-supremo.png": "a5087db2e0a91ffdf9822b045a99c0a5fbebee562029c9be41557ae033522dfb"}))assert.equal(sha(name),expected);
});
