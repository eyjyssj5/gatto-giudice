const assert=require('node:assert/strict');
const {test}=require('node:test');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'../www');
const css=fs.readFileSync(path.join(root,'styles.css'),'utf8');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
test('sei ritratti senza taglio al busto: contenimento integrale',()=>{
  assert.match(css,/V12: foto integrali/);
  assert.match(css,/object-fit:contain/);
  assert.match(css,/aspect-ratio:\s*1\.12/);
  assert.match(html,/styles\.css\?v=play16/);
  for(const id of ['dolce','severo','ironico','corrotto','pigro','supremo']) assert.match(app,new RegExp('id:"'+id+'"'));
});
test('dettatura Android mantenuta e limiti prova personale rimossi',()=>{
  assert.match(app,/Capacitor\?\.Plugins\?\.SpeechRecognition/);
  assert.match(app,/const MAX = 10/);
  assert.doesNotMatch(app,/TEST\.ui\(state\.lingua\)\.unlocked/);
});
