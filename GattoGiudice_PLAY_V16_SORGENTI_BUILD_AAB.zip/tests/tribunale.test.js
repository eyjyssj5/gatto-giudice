const assert = require('node:assert/strict');
const test = require('node:test');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const web = path.resolve(__dirname,'../www');
const base = require(path.join(web,'i18n.js'));
const sandbox = {window:{}};
vm.runInNewContext(fs.readFileSync(path.join(web,'tribunale-i18n.js'),'utf8'),sandbox);
const add=sandbox.window.GattoTribunaleLingue;
test('tutte le 12 lingue hanno 6 nomi di giudici',()=>{
 assert.equal(base.codes.length,12);
 for(const lang of base.codes){const t=add.get(lang);
   assert.ok(t.court && t.locked && t.premium && t.free);
   for(const id of ['dolce','severo','ironico']) assert.ok(base.text(lang,id));
   for(const id of ['corrotto','pigro','supremo']) assert.ok(t[id]);
   for(const id of ['dolce','severo','ironico','corrotto','pigro','supremo']) assert.ok(t.descriptions[id]);
 }
});
test('l app non contiene funzioni vocali',()=>{
 const html=fs.readFileSync(path.join(web,'index.html'),'utf8');
 const js=fs.readFileSync(path.join(web,'app.js'),'utf8');
 assert.doesNotMatch(html,/voce\.js|btn-voce|GattoVoce/);
 assert.doesNotMatch(js,/GattoVoce|synthesis|speechSynthesis/);
});
test('le fotografie originali e i due nuovi gatti esistono',()=>{
 for(const id of ['dolce','severo','ironico'])assert.ok(fs.statSync(path.join(web,'img','gatto-'+id+'.png')).size>1e6);
 for(const id of ['corrotto','pigro'])assert.ok(fs.statSync(path.join(web,'img','gatto-'+id+'.svg')).size>1000);
});

test('il sesto giudice e premium e usa solo la foto fornita dall utente',()=>{
 const js=fs.readFileSync(path.join(web,'app.js'),'utf8');
 assert.match(js,/\{id:"supremo",img:"img\/gatto-supremo\.png",free:false\}/);
 assert.equal(fs.statSync(path.join(web,'img','gatto-supremo.png')).size,fs.statSync(path.join(web,'../icone/icona_originale_1024.png')).size);
 assert.match(js,/\["center","right","hidden-right","hidden-right","hidden-left","left"\]/);
});
