/* AIVEVIA Gatto Giudice: tribunale rotante, 12 lingue, senza sintesi vocale. */
(function () {
"use strict";
const el = id => document.getElementById(id);
const LANG = window.GattoLingue;
const EXTRA = window.GattoTribunaleLingue;
const SERVER = "https://gatto-giudice-ai.eyjyssj.workers.dev";
const KEY = "gatto.play.v1.stato";
const MAX = 10; // limite locale, da applicare anche lato server
const JUDGES = [
 {id:"dolce",img:"img/gatto-dolce-approvato.png",free:true},
 {id:"severo",img:"img/gatto-severo-approvato.png",free:false},
 {id:"ironico",img:"img/gatto-ironico.png",free:false},
 {id:"corrotto",img:"img/gatto-corrotto-approvato.png",free:false},
 {id:"pigro",img:"img/gatto-pigro-approvato.png",free:false},
 {id:"supremo",img:"img/gatto-supremo.png",free:false}
];
const sDay = () => { const x=new Date(); return [x.getFullYear(),String(x.getMonth()+1).padStart(2,"0"),String(x.getDate()).padStart(2,"0")].join("-"); };
const initialLang=LANG.normalize(navigator.language||"it");
function read(){try{const obj=JSON.parse(localStorage.getItem(KEY))||{};return {...{lingua:initialLang,carattere:"dolce",decisioni:[],dispositivo:null},...obj,decisioni:Array.isArray(obj.decisioni)?obj.decisioni:[]};}catch{return {lingua:initialLang,carattere:"dolce",decisioni:[],dispositivo:null};}}
function write(v){localStorage.setItem(KEY,JSON.stringify(v));}
let state=read();
// Google Play: Dolce gratis, altri cinque premium con Play Billing.
if(!JUDGES.some(j=>j.id===state.carattere))state.carattere="dolce";
let index=Math.max(0,JUDGES.findIndex(j=>j.id===state.carattere));
write(state);
let busy=false,lastVerdict="",lastApproved=false,startX=null;
const tr=()=>EXTRA.get(state.lingua);
const t=(key,vars)=>LANG.text(state.lingua,key,vars);
const name=(id)=> ["corrotto","pigro","supremo"].includes(id)?tr()[id]:t(id);
const escapeText=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));
// Dettatura: riconoscimento vocale (se supportato dal telefono) oppure microfono della tastiera.
const DICTATION = {
 it:["Detta il tuo caso", "Ti ascolto. Parla adesso…", "Testo inserito. Controllalo e consegna al gatto.", "Usa il microfono sulla tastiera del telefono.", "Non ho capito. Riprova o detta dalla tastiera.","Ferma dettatura"],
 es:["Dicta tu caso","Te escucho. Habla ahora…","Texto añadido. Revísalo antes de enviarlo.","Usa el micrófono del teclado.","No te entendí. Inténtalo de nuevo.","Detener dictado"],
 en:["Dictate your case","Listening. Speak now…","Text inserted. Check it before submitting.","Use the microphone on your phone's keyboard.","I didn't catch that. Try again.","Stop dictation"],
 pt:["Dite seu caso","Estou ouvindo. Fale agora…","Texto inserido. Confira antes de enviar.","Use o microfone do teclado.","Não entendi. Tente novamente.","Parar ditado"],
 fr:["Dicter votre décision","Je vous écoute. Parlez…","Texte ajouté. Vérifiez-le avant d'envoyer.","Utilisez le micro du clavier.","Je n'ai pas compris. Réessayez.","Arrêter la dictée"],
 de:["Fall diktieren","Ich höre zu. Bitte sprechen…","Text eingefügt. Vor dem Senden prüfen.","Nutze das Mikrofon der Tastatur.","Nicht verstanden. Bitte erneut versuchen.","Diktat beenden"],
 nl:["Dicteer je zaak","Ik luister. Spreek nu…","Tekst ingevuld. Controleer voor verzending.","Gebruik de microfoon op het toetsenbord.","Niet verstaan. Probeer opnieuw.","Stop dicteren"],
 pl:["Podyktuj sprawę","Słucham. Mów teraz…","Wpisano tekst. Sprawdź przed wysłaniem.","Użyj mikrofonu klawiatury.","Nie zrozumiałem. Spróbuj ponownie.","Zatrzymaj dyktowanie"],
 ru:["Продиктовать дело","Слушаю. Говорите…","Текст введён. Проверьте перед отправкой.","Нажмите микрофон на клавиатуре.","Не расслышал. Попробуйте ещё раз.","Остановить запись"],
 tr:["Davanı sesle yaz","Dinliyorum. Konuşun…","Metin eklendi. Göndermeden önce kontrol et.","Klavyenin mikrofonunu kullanın.","Anlaşılmadı. Tekrar deneyin.","Dikteyi durdur"],
 ar:["إملاء القضية صوتياً","أستمع إليك. تحدث الآن…","تم إدخال النص. راجعه قبل الإرسال.","استخدم ميكروفون لوحة المفاتيح.","لم أفهم. حاول مرة أخرى.","إيقاف الإملاء"],
 zh:["语音输入案件","正在聆听，请开始说话…","已填入文字。提交前请检查。","请使用手机键盘上的麦克风。","没听清，请再试一次。","停止听写"]
};
const SPEECH_LOCALES={it:"it-IT",es:"es-ES",en:"en-US",pt:"pt-PT",fr:"fr-FR",de:"de-DE",nl:"nl-NL",pl:"pl-PL",ru:"ru-RU",tr:"tr-TR",ar:"ar-SA",zh:"zh-CN"};
let recognizer=null;
let listening=false;
function micWords(){return DICTATION[state.lingua]||DICTATION.it;}
function showMic(message){el("dettatura-stato").textContent=message;}
function micState(active){listening=active;el("btn-detta").setAttribute("aria-pressed",String(active));el("btn-detta").textContent=active?"⏹":"🎙️";el("btn-detta").setAttribute("aria-label",active?micWords()[5]:micWords()[0]);el("btn-detta").title=active?micWords()[5]:micWords()[0];}
async function dictate(){
 if(listening){try{recognizer?.stop();await window.Capacitor?.Plugins?.SpeechRecognition?.stop?.();}catch(_){};micState(false);return;}
 // Quando disponibile usa il plugin nativo Capacitor, che supporta Android/iOS.
 const native=window.Capacitor?.Plugins?.SpeechRecognition;
 if(native){
   micState(true);showMic(micWords()[1]);
   try{
     const available=await native.available();if(available?.available===false)throw Error("unavailable");
     const p=await native.checkPermissions();
     if(p?.speechRecognition!=="granted"){
       const perm=await native.requestPermissions();
       if(perm?.speechRecognition!=="granted")throw Error("denied");
     }
     const result=await native.start({language:SPEECH_LOCALES[state.lingua],maxResults:1,popup:true,partialResults:false,prompt:micWords()[1]});
     const heard=result?.matches?.[0];
     if(heard){el("decisione").value=String(heard).slice(0,120);el("decisione").dispatchEvent(new Event("input",{bubbles:true}));showMic(micWords()[2]);}
     else showMic(micWords()[4]);
   }catch(e){
     console.warn("Dettatura Android:",e);
     const denied=/denied|permission/i.test(String(e?.message||e));
     const msg=denied
       ? ({it:"Autorizza il microfono nelle impostazioni dell'app e riprova.",es:"Autoriza el micrófono en los ajustes de la app.",en:"Allow microphone access in the app settings."}[state.lingua]||micWords()[4])
       : micWords()[4]+" "+micWords()[3];
     showMic(msg);el("decisione").focus();
   }
   finally{micState(false);}
   return;
 }
 const Recognition=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!Recognition){showMic(micWords()[3]);el("decisione").focus();return;}
 try{
   recognizer=new Recognition();recognizer.lang=SPEECH_LOCALES[state.lingua];recognizer.interimResults=false;recognizer.continuous=false;recognizer.maxAlternatives=1;
   recognizer.onresult=e=>{const text=e.results?.[0]?.[0]?.transcript;if(text){el("decisione").value=String(text).slice(0,120);el("decisione").dispatchEvent(new Event("input",{bubbles:true}));showMic(micWords()[2]);}};
   recognizer.onerror=()=>{showMic(micWords()[3]);el("decisione").focus();};
   recognizer.onend=()=>micState(false);
   micState(true);showMic(micWords()[1]);recognizer.start();
 }catch(e){micState(false);showMic(micWords()[3]);el("decisione").focus();}
}
el("btn-detta").addEventListener("click",dictate);

function device(){if(!state.dispositivo){state.dispositivo=window.crypto?.randomUUID?.()||"d-"+Date.now()+"-"+Math.random().toString(36).slice(2);write(state);}return state.dispositivo;}
function localRemaining(){if(state.rimasteData===sDay() && typeof state.rimaste==="number")return Math.max(0,state.rimaste);return Math.max(0,MAX-window.Gatto.decisioniDi(state.decisioni,sDay()).length);}
function point(i){return (i+JUDGES.length)%JUDGES.length;}
function carouselPositions(i){const offset=(i-index+JUDGES.length)%JUDGES.length;return ["center","right","hidden-right","hidden-right","hidden-left","left"][offset];}
function paid(id){return id==='dolce'||Boolean(window.GattoPremium?.owned(id));}
function panel(){
 const j=JUDGES[index],x=tr();const e=el('judge-panel');
 e.innerHTML='<div class="who">'+escapeText(name(j.id))+'</div><div class="desc">'+escapeText(x.descriptions[j.id])+'</div>';
 if(!paid(j.id)){
   const btn=document.createElement('button');btn.type='button';btn.className='premium-buy';
   const buy=({it:'Sblocca',en:'Unlock',es:'Desbloquear',fr:'Débloquer'})[state.lingua]||'Unlock';
   const price=window.GattoPremium?.price(j.id)||'';
   btn.textContent=buy+' '+name(j.id)+(price?' · '+price:'');
   btn.addEventListener('click',async()=>{if(!window.GattoPremium?.ready()){btn.disabled=true;btn.textContent='Google Play non disponibile';return;}btn.disabled=true;try{await window.GattoPremium.buy(j.id);}finally{drawCarousel();showRemaining();}});
   e.append(btn);
 }
 el('active-name').textContent=name(j.id).toUpperCase();
}
function drawCarousel(){
 const container=el("giudici");container.textContent="";
 JUDGES.forEach((j,i)=>{
  const pos=carouselPositions(i),b=document.createElement("button");b.type="button";b.className="judge-card"+(paid(j.id)?"":" is-locked");b.dataset.judge=j.id;b.dataset.position=pos;
  b.setAttribute("aria-label",name(j.id));b.setAttribute("aria-current",pos==="center"?"true":"false");b.tabIndex=pos==="center"||pos==="left"||pos==="right"?0:-1;
  b.innerHTML='<span class="judge-portrait"><img alt="" loading="'+(pos==="center"?"eager":"lazy")+'" src="'+j.img+'?v=16"></span><span class="name">'+escapeText(name(j.id))+'</span>'+(paid(j.id)?"":'<span class="lock" aria-hidden="true">🔒</span>');
  b.addEventListener("click",()=>{if(i!==index){selectIndex(i);}else{document.getElementById("judge-panel").scrollIntoView({block:"nearest",behavior:"smooth"});}});
  container.append(b);
 });
 el("dots").innerHTML=JUDGES.map((_,i)=>'<i class="dot'+(i===index?' selected':'')+'"></i>').join("");
 const j=JUDGES[index],x=tr();
 panel();
 el("giudice-prev").setAttribute("aria-label",x.prev);el("giudice-next").setAttribute("aria-label",x.next);
}
function selectIndex(i){index=point(i);state.carattere=JUDGES[index].id;write(state);lastVerdict="";el("esito").hidden=true;el("fumetto").textContent=t("intro");renderJudges();showRemaining();}
function renderJudges(){const cards=[...el("giudici").children];
 cards.forEach((b,i)=>{const pos=carouselPositions(i);b.dataset.position=pos;b.setAttribute("aria-current",pos==="center"?"true":"false");b.tabIndex=["center","left","right"].includes(pos)?0:-1;});
 el("dots").innerHTML=JUDGES.map((_,i)=>'<i class="dot'+(i===index?' selected':'')+'"></i>').join("");
 const j=JUDGES[index],x=tr();
 panel();
}
function showHistory(){
 const list=el("lista-oggi");list.textContent="";
 const today=window.Gatto.decisioniDi(state.decisioni,sDay());
 if(!today.length){const li=document.createElement("li");li.textContent=t("noneToday");list.append(li);}
 today.forEach(d=>{const li=document.createElement("li");const span=document.createElement("span");span.textContent=(d.carattere?name(d.carattere)+" · ":"")+d.testo;const icon=document.createElement("strong");icon.textContent=d.approva?"👍":"👎";li.append(span,icon);li.addEventListener("click",()=>{el("decisione").value=d.testo;el("decisione").focus();});list.append(li);});
 const r=window.Gatto.riepilogo(state.decisioni,sDay());el("riepilogo").textContent=r.totale?t("stats",{yes:r.approvate,no:r.bocciate,total:r.totale}):t("noneWeek");
}
function showRemaining(){const n=localRemaining();el("contatore").textContent=t("remaining",{n});el("btn-giudica").disabled=busy||!paid(state.carattere)||n<=0;}
function translate(){state.lingua=LANG.normalize(state.lingua);const x=tr();document.documentElement.lang=state.lingua;document.documentElement.dir=state.lingua==="ar"?"rtl":"ltr";document.title=t("title");
 el("titolo").textContent=t("title");el("lingua-label").textContent=t("language");el("lingua").value=state.lingua;micState(false);showMic("");
 el("test-banner").hidden=true;el("tribunal-title").textContent=x.court;el("tribunal-subtitle").textContent=x.subtitle;el("case-label").textContent=x.case;el("submit-label").textContent=x.submitLabel;el("decision-label").textContent=x.decisionLabel;el("decisione").placeholder=t("placeholder");el("titolo-oggi").textContent=t("today");el("titolo-settimana").textContent=t("week");el("footer-tag").textContent=x.foot;
 drawCarousel();showHistory();showRemaining();el("fumetto").textContent=lastVerdict||t("intro");if(lastVerdict){el("esito").hidden=false;el("pollice").textContent=lastApproved?"👍":"👎";el("esito-frase").textContent=lastVerdict;}
}
async function judge(text){
 if(busy||!paid(state.carattere)){showRemaining();return;}
 if(localRemaining()<=0){el("fumetto").textContent=t("limit");showRemaining();return;}
 busy=true;showRemaining();el("fumetto").textContent=t("thinking");el("esito").hidden=true;
 const selected=state.carattere;const card=el("giudici").querySelector('[data-judge="'+selected+'"]');card?.classList.add("deciding");
 try{
  const ctl=new AbortController();
  const timeout=setTimeout(()=>ctl.abort(),26000);
  let r;
  try{
    r=await fetch(SERVER+"/giudica",{
      method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({decisione:text,carattere:selected,dispositivo:device(),lingua:state.lingua}),
      signal:ctl.signal
    });
  }finally{clearTimeout(timeout);}
  if(r.status===429){el("fumetto").textContent=t("pause");return;}
  if(!r.ok){
    if(r.status===400 && ["corrotto","pigro","supremo"].includes(selected)){
      el("fumetto").textContent=state.lingua==="it"?"Aggiorna prima il servizio AI Cloudflare alla versione V8.":"Update the Cloudflare AI service to V8 first.";
      return;
    }
    el("fumetto").textContent=t("serverError");return;
  }
  const data=await r.json();
  if(typeof data.frase!=="string"||typeof data.approva!=="boolean")throw Error("Invalid response");
  lastVerdict=data.frase;lastApproved=data.approva;state.decisioni.push({data:sDay(),testo:text,approva:data.approva,frase:data.frase,carattere:selected});
  state.decisioni=state.decisioni.slice(-250);const local=Math.max(0,MAX-window.Gatto.decisioniDi(state.decisioni,sDay()).length);
  state.rimaste=typeof data.rimaste==="number"?Math.max(0,Math.min(local,data.rimaste)):local;state.rimasteData=sDay();write(state);
  el("fumetto").textContent=lastVerdict;el("esito-frase").textContent=lastVerdict;el("pollice").textContent=lastApproved?"👍":"👎";el("esito").hidden=false;el("decisione").value="";
 }catch(e){el("fumetto").textContent=e?.name==="AbortError"?t("timeout"):t("serverError");}
 finally{busy=false;card?.classList.remove("deciding");showRemaining();showHistory();}
}
window.addEventListener("gatto-premium-update",()=>{drawCarousel();showRemaining();});
el("giudice-prev").addEventListener("click",()=>{selectIndex(index-1);});
el("giudice-next").addEventListener("click",()=>{selectIndex(index+1);});
el("judges-viewport").addEventListener("touchstart",e=>{startX=e.touches[0]?.clientX??null;},{passive:true});
el("judges-viewport").addEventListener("touchend",e=>{if(startX===null)return;const diff=(e.changedTouches[0]?.clientX??startX)-startX;startX=null;if(Math.abs(diff)>45){selectIndex(index+(diff<0?1:-1));}},{passive:true});
el("lingua").addEventListener("change",e=>{state.lingua=LANG.normalize(e.target.value);write(state);lastVerdict="";el("esito").hidden=true;translate();});
el("form-decisione").addEventListener("submit",e=>{e.preventDefault();const text=el("decisione").value.trim();if(text)judge(text);});
el("decisione").addEventListener("focus",()=>{});
translate();
// Nessuna rotazione automatica: il giudice cambia SOLO su azione esplicita dell’utente.
})();
